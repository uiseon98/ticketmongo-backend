package com.team03.ticketmon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketmonGoApplicationTests {

    @Test
    void contextLoads() {
    }

}
