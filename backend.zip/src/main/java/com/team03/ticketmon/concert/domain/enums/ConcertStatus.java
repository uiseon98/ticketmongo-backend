package com.team03.ticketmon.concert.domain.enums;

public enum ConcertStatus {
	SCHEDULED,
	ON_SALE,
	SOLD_OUT,
	CANCELLED,
	COMPLETED
}
