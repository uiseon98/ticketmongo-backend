package com.team03.ticketmon.concert.domain.enums;

public enum SeatGrade {
	VIP,
	R,
	S,
	A
}