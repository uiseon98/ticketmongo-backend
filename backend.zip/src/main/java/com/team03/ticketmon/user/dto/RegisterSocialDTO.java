package com.team03.ticketmon.user.dto;

public record RegisterSocialDTO(
        String email,
        String name
) {
}
