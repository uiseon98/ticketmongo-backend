package com.team03.ticketmon.notification.domain.enums;

public enum NotificationType {
    CONCERT_REMINDER,
    BOOKING_CONFIRMED
}
