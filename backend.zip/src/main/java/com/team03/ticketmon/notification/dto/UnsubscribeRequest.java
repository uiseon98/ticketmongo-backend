package com.team03.ticketmon.notification.dto;

import lombok.Data;

@Data
public class UnsubscribeRequest {
    private String playerId;
}
