package com.team03.ticketmon.notification.domain.enums;

public enum SubscriptionStatus {
    SUBSCRIBED, UNSUBSCRIBED
}
