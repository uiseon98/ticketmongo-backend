package com.team03.ticketmon.notification.domain.enums;

public enum Status {
    PENDING,
    SENT,
    FAILED,
    DELIVERED,
    OPENED
}
