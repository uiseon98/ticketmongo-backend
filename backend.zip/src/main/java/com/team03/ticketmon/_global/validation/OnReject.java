package com.team03.ticketmon._global.validation;

// 유효성 검사 그룹의 마커 역할용
public interface OnReject {}